function [ BranchCentroid ] = OptimisationSteps( N , k , BranchCentroid , ClusterOriginBranch )
%OPTIMISATIONSTEPS Summary of this function goes here
%   Detailed explanation goes here
[r,~,~] = size(ClusterOriginBranch);
batchsize = 1;
%begin optimisation loop
for step = 1:N
   %assign data to centrioids
   randomIndex = randperm(r);
   randomIndex = randomIndex(1:ceil(r*batchsize));
   stepClusterBatch = ClusterOriginBranch(randomIndex,:,:);
   [ ClusterAssignment ] = AssignToClosest( stepClusterBatch ,  BranchCentroid );
   %update each centriod 
   for cluster = 1: k
       idx = find(ClusterAssignment==cluster);
       if length(idx) > 1
            BranchCentroid(cluster,:,:) = mean(stepClusterBatch(idx,:,:));
       elseif length(idx) == 1
           BranchCentroid(cluster,:,:) = stepClusterBatch(idx,:,:);
       end
   end
   fprintf('optimisation step of %d out of %d done \n',step,N)
   batchsize = batchsize - .0045;
end
end

