function [ ClusterAssignment ] = AssignToClosest( data ,  clusters , method)
%ASSIGNTOCLOSEST creates an assignment index vector where each row shows
%that examples beloning cluster
%for each cluster compute exmaples distance to cluster point
switch nargin
    case 2
        [distances] = EuclideanDistance( data , clusters );
        %find the closest cluster to each point and assignment it to that cluster
        [~,ClusterAssignment] = min(distances,[],2);
    case 3
        [distances] = EuclideanDistance( data , clusters , method );
        %find the closest cluster to each point and assignment it to that cluster
        [~,ClusterAssignment] = min(distances,[],2);
end

end

