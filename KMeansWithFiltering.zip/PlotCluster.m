function PlotCluster(Data , Assignments)
figure();
hold on;
subplot(6,10,1);
imagePlot = 1;
k = unique(Assignments);
for cluster = k'
    idx = find(Assignments==cluster);
    fprintf('number of exmaples in cluster %d was %d \n',cluster,length(idx));
    if (length(idx) >= 20)
        for image = 1 : 20
        remakeImage = uint8(reshape(Data(idx(image),:,:),[100 100 3]));
        h = subplot(6,10,imagePlot);
        h.Position = h.Position  + [ 0 0 .01 .01];
        imshow(remakeImage)
        imagePlot = imagePlot + 1;
        end
    else
        for image = 1 : length(idx)
        remakeImage = uint8(reshape(Data(idx(image),:,:),[100 100 3]));
        h = subplot(6,10,imagePlot);
        h.Position = h.Position  + [ 0 0 .01 .01];
        imshow(remakeImage)
        imagePlot = imagePlot + 1;
        end
        imagePlot = cluster*20;
    end
end
suptitle('plot of images found in each cluster')
hold off;