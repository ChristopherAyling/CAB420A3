function [ BranchCentroid ] = FilteringInitCluster( ClusterOriginBranch , ClusterOriginLabels)
%FILTERINGINITCLUSTER Summary of this function goes here
%   Detailed explanation goes here
BranchCentroid = [];
%create each centroid
k = unique(ClusterOriginLabels);
for i = k'
    choices = find(ClusterOriginLabels == i);
    idx = randi(length(choices));
    BranchCentroid(end+1,:,:) = ClusterOriginBranch(choices(idx),:,:);
end

end

