function [LeafCentroids,branches,leafs,validationSet,error] = KMeansWithFiltering (Data , Labels ,n)
%% Randomize given data and labels for training
LeafCentroids = [];
[r,~,~] = size(Data);
randomIndex = randperm(r);
ClusterOriginBranch = Data(randomIndex,:,:);
ClusterOriginLabels = Labels(randomIndex);
%spilt the testing and training data
trainPortion = ceil(.8*r);
validationSet.Data = ClusterOriginBranch(trainPortion+1:end,:,:);
validationSet.Labels = ClusterOriginLabels(trainPortion+1:end);
ClusterOriginBranch = ClusterOriginBranch(1:trainPortion,:,:);
ClusterOriginLabels = ClusterOriginLabels(1:trainPortion);

[r,~,~] = size(ClusterOriginBranch);


%% Find random exmaples for each desired class as initial centroids

BranchCentroid = [];
%create each centroid
for i = 1:3
    choices = find(ClusterOriginLabels == i);
    idx = randi(length(choices));
    BranchCentroid(end+1,:,:) = ClusterOriginBranch(choices(idx),:,:);
end

%% Compute initilisation Optimisation step
%Parameters 
k = 3; %number of desired clusters
N = n; %number of optimisation steps
leafTheshold = ceil(r*.05); %theshold for branches to become leafs
batchsize = 1;
%begin optimisation loop
for step = 1:N
   %assign data to centrioids
   randomIndex = randperm(r);
   randomIndex = randomIndex(1:ceil(r*batchsize));
   stepClusterBatch = ClusterOriginBranch(randomIndex,:,:);
   [ ClusterAssignment ] = AssignToClosest( stepClusterBatch ,  BranchCentroid );
   %update each centriod 
   for cluster = 1: k
       idx = find(ClusterAssignment==cluster);
       BranchCentroid(cluster,:,:) = mean(stepClusterBatch(idx,:,:));
   end
   fprintf('optimisation step of %d out of %d done \n',step,N)
   batchsize = batchsize - .009;
end
%show images that have been clustered
[ ClusterAssignment ] = AssignToClosest( Data ,  BranchCentroid );
PlotCluster(Data , ClusterAssignment)

%% Check to see if any branches exist
%check original cluster
branches.NUM = 0;
branches.INFO = struct('X',{},'Y',{},'Centroid',{},'Closed',{},'Assign',{});
leafs.NUM = 0;
leafs.INFO = struct('X',{},'Y',{},'Centroid',{},'Closed',{},'Assign',{});
for cluster = 1 : k
    %check the size of each cluster
    if ( length(ClusterAssignment==cluster) > leafTheshold )
        %increase the total number of branches
        branches.NUM = branches.NUM + 1;
        index = branches.NUM;
        %create new set of information about branch
        branches.INFO(index).X = Data(ClusterAssignment==cluster,:,:);
        branches.INFO(index).Y = Labels(ClusterAssignment==cluster);
        %intitlise the centriod for this branch
        [ branches.INFO(index).Centroid ] = FilteringInitCluster( ...
          branches.INFO(index).X , branches.INFO(index).Y);
        %run optimisation on branch
        [ branches.INFO(index).Centroid ] = OptimisationSteps( N , k ,...
          branches.INFO(index).Centroid , branches.INFO(index).X );
         branches.INFO(index).Closed = 0;      
    end
end
%show the clustering of data of each new branch
for j = 1 : branches.NUM
    fprintf('computing the assignments for branch %d now \n',j)
    [  branches.INFO(j).Assign ] = AssignToClosest( branches.INFO(j).X ,...
      branches.INFO(j).Centroid );
     PlotCluster(branches.INFO(j).X , branches.INFO(j).Assign)
end
%% Now we continue to branch out until only leafs exists at the end
branchesExist = 1;
while(branchesExist)
    branchesExist = 0;
    for j = 1 : branches.NUM
        %if the branch hasnt been closed check its clusters
        if ~(branches.INFO(j).Closed)
            for cluster = 1 : k
                if ( length( find(branches.INFO(j).Assign==cluster)) > leafTheshold )
                    %increase the total number of branches
                    branches.NUM = branches.NUM + 1;
                    index = branches.NUM;
                    %create new set of information about branch
                    branches.INFO(index).X = branches.INFO(j).X ...
                        (branches.INFO(j).Assign==cluster,:,:);
                    branches.INFO(index).Y = branches.INFO(j).Y ...
                        (branches.INFO(j).Assign==cluster);
                    %intitlise the centriod for this branch
                    [ branches.INFO(index).Centroid ] = FilteringInitCluster( ...
                      branches.INFO(index).X , branches.INFO(index).Y);
                    %run optimisation on branch
                    fprintf('Branch %d optimisation step occuring \n',index)
                    [ branches.INFO(index).Centroid ] = OptimisationSteps( N , k ,...
                      branches.INFO(index).Centroid , branches.INFO(index).X );
                     branches.INFO(index).Closed = 0;
                    fprintf('computing the assignments for branch %d now \n',index)
                    [  branches.INFO(index).Assign ] = AssignToClosest( ...
                       branches.INFO(index).X ,...
                       branches.INFO(index).Centroid );
                     branchesExist = 1;
                else
                    if  length( find(branches.INFO(j).Assign==cluster)) > 10
                        %create new leaf entry into the clustering algorithm
                        leafs.NUM = leafs.NUM + 1;
                        index = leafs.NUM;
                        fprintf('new leaf created , total leafs is %d \n',leafs.NUM)
                        leafs.INFO(index).X = branches.INFO(j).X ...
                            (branches.INFO(j).Assign==cluster,:,:);
                        leafs.INFO(index).Y = branches.INFO(j).Y ...
                            (branches.INFO(j).Assign==cluster);
                    end
                end
            end
            branches.INFO(j).Closed = 1;
        end
    end
end

%% now we compute the leafs centroids
for j = 1:leafs.NUM
    [ leafs.INFO(j).Centroid ] = FilteringInitCluster( ...
      leafs.INFO(j).X , leafs.INFO(j).Y);
    %run optimisation on branch
      fprintf('leaf %d optimisation step occuring \n',j)
    [ leafs.INFO(j).Centroid ] = OptimisationSteps( N , k ,...
      leafs.INFO(j).Centroid , leafs.INFO(index).X );
      leafs.INFO(j).Closed = 1;
end

%% now check how these centroids works in our test set
% air = figure();
% land = figure();
% water = figure();
validationSet.Assign = [];
for j = 1: length(validationSet.Labels)
    distances = [];
    for class = 1 : k
        classDistances = [];
        for leaf = 1:leafs.NUM
            if length(leafs.INFO(leaf).Centroid) >= k
                classDistances(end+1) = sqrt(sum(sum((leafs.INFO(leaf).Centroid(class,:,:)- validationSet.Data(j,:,:)).^2)));
            end
        end
        distances(end+1) = min(classDistances);
    end
    [~,idx] = min(distances);
    validationSet.Assign(end+1)=idx;
end
validationSet.Assign = validationSet.Assign';
%% compute error in test set
fprintf('number of test exmaples is %d\n',length(validationSet.Labels))
misClass = validationSet.Assign ~= validationSet.Labels;
numberOfErrors = find(misClass == 0);
fprintf('number of odd clustering images was %d\n',length(numberOfErrors))
error = length(numberOfErrors)/length(validationSet.Labels);
fprintf('The error rate was %2.8f\n %',error)
PlotCluster(validationSet.Data , validationSet.Assign)
